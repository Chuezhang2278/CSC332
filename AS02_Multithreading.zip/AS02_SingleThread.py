import math
import timeit

def countDivisors(n) : # Function to calculate how many divisors in a number
    cnt = 0
    for i in range(1, (int)(math.sqrt(n)) + 1) : 
        if (n % i == 0) : 

            if (n / i == i) : 
                cnt = cnt + 1
            else : 
                cnt = cnt + 2
                  
    return cnt 

start = timeit.default_timer()
Big = 0
Integer = 0

for i in range(1,10000):
    print(i)
    if(Big <= countDivisors(i)):
        Big = countDivisors(i)
        Integer = i

stop = timeit.default_timer()
execution_time = stop - start
    
print(Integer)
print("Program Executed in", execution_time, "Seconds")