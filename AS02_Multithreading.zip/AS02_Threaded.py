import math
import timeit
import threading
from concurrent.futures import ThreadPoolExecutor

def increment():
    global i 
    i += 1

def countDivisors(n) : # Function to calculate how many divisors in a number
    count = 0
    for i in range(1, (int)(math.sqrt(n)) + 1) : 
        if (n % i == 0) : 

            if (n / i == i) : 
                count = count + 1
            else : 
                count = count + 2
                  
    return count 

def largestInteger():
    global Big 
    global Integer

    while(i < 10000):
        increment()
        if(Big <= countDivisors(i)):
            Big = countDivisors(i)
            Integer = i
    
    print(Integer)

def Blah():
    global Big
    global Integer
    global i
    
    i = 0
    Big = 0
    Integer = 0
    
    t1 = threading.Thread(target = largestInteger)
    t2 = threading.Thread(target = largestInteger)
    t3 = threading.Thread(target = largestInteger)
    
    t1.start()
    t2.start()
    t3.start()
    
    t1.join()
    t2.join()
    t3.join()
    

start = timeit.default_timer()
Blah()
stop = timeit.default_timer()
execution_time = stop - start
    
print("Program Executed in", execution_time, "Seconds")